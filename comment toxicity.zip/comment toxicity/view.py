import pickle

# Load a pickled object from a file
with open("model.pkl", "rb") as f:
    loaded_object = pickle.load(f)

# Now you can use the loaded_object
print(loaded_object)
