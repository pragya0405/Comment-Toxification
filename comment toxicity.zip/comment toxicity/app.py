import streamlit as st
import pickle
import string
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords 
from nltk.stem import PorterStemmer

tfidf = pickle.load(open("tf_idf.pkl", "rb"))
nb_model = pickle.load(open("model.pkl", "rb"))

st.text("Comment Toxicity Classification using ML")
comment = st.text_input("Write comment")


success_button_style = "success_button_style"

def ans(text: str):
    text_tfidf = tfidf.transform([text]).toarray()
    prediction = nb_model.predict(text_tfidf)
    return prediction[0]


if st.button("click here to predict"):
    if ans(comment) == 1:
        st.success("Toxic")
    else:
        st.success("Non-toxic")
